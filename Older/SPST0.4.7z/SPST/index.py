from TN import tracnghiem
import customtkinter as ctk
from CTkListbox import *
from showkq import xemkq

'''
SCRIPT BY BẢO

!!!!!!!!!!!!!!!!!!!!!!
SCRIPT SỬ DỤNG THƯ VIỆN NGOÀI
customtkinter và CTkListbox
ĐỂ SỬ DỤNG ĐƯỢC SCRIPT CẦN CÀI ĐẶT 2 THƯ VIỆN TRÊN
!!!!!!!!!!!!!!!!!!!!!!

TÍNH NĂNG:
ÔN THI TIN HSG 
SET TÊN THÍ SINH
RESET DỮ LIỆU
CHỌN ĐỀ
LÀM ĐỀ (CÓ THỜI GIAN)
CHẤM ĐIỂM + GHI LẠI SỐ LẦN LÀM
XEM KẾT QUẢ

HD:
Tùy theo số đề thì userdata sẽ có format:
Dòng 1: Tên thí sinh - Được nhập ở cửa sổ chào mừng
Dòng 2: Số lần làm đề 1 với số điểm của lần ấy 
Các dòng sau tương ứng với số đề
Có thể reset lại toàn bộ bằng nút reset ở trang chào mừng

Yêu cầu của đề: Bộ câu hỏi, thời gian, câu trả lời đúng
Format bộ câu hỏi:
Các câu hỏi nằm trong 1 list chứa tuple, mỗi tuple chứa 1 câu hỏi và 4 đáp án bên trong một cái list khác bên trong 1 cái tuple =)))
(Không cần số câu hỏi và số đáp án có thể lớn hơn 4)
Ví dụ ở dưới:
questions_data = [
    ("Trong các công việc hàng ngày chúng ta cần làm gì để có hiệu quả?", 
    [
        "Cần có kế hoạch cụ thể cho từng công việc", 
        "Nhờ người khác làm giúp công việc", 
        "Thuê người khác làm thay công việc của mình", 
        "Gặp công việc nào làm công việc đó"
    ])
]

Format câu trả lời đúng:
Một list chứa các index của đáp án đúng tương ứng với câu hỏi 
Ví dụ: [0,1,2,3,3,2,1,0,1,2] = Câu 1: A, Câu 2: B, Câu 3: C, Câu 4: D, Câu 5: D, Câu 6: C, Câu 7: B, Câu 8: A, Câu 9: B, Câu 10: C
answers = [0,1,2,3,3,2,1,0,1,2]

Format thời gian:
Thời gian làm bài theo giây
'''
# BƯỚC 1: THÊM CÂU HỎI (CHƯA CÓ ĐỀ DẠNG DATABASE HAY TXT =)))
questions_data = [
    ("Nhập câu hỏi ở đây", 
    [
        "Các câu trả lời"
    ])
    # THÊM CÁC CÂU TƯƠNG TỰ
]
# BƯỚC 2: CÂU TRẢ LỜI:
'0 = A', '1 = B', '2 = C', '3 = D'
answers = [3]
# BƯỚC 3: THỜI GIAN
ltime = 60*10 # 10 phút

# BƯỚC 4: CHẠY THỬ SCRIPT =)))

def hsg(main):
    main.destroy()

    def capnhat_userdata():
        if tende.get() in bode:
            with open("userdata.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()
            index = list(bode.keys()).index(tende.get())
            ldl = lines[index+1].strip().split()
            dulienbai = str(f"{ldl[0]} với số điểm {ldl[1]}")
            if solanlam.get() != f"Số lần làm đề: {dulienbai}":
                solanlam.set(f"Số lần làm đề: {dulienbai}")

        locde.after(1000, capnhat_userdata)  
    

    def layde(event):
        nonlocal tende, solanlam
        selected = de.get()  # Lấy giá trị của phần tử được chọn
        if selected:
            tende.set(selected)  
            with open("userdata.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()
            index = list(bode.keys()).index(selected) 
            ldl = lines[index+1].strip().split() 
            dulienbai = str(f"{ldl[0]} với số điểm {ldl[1]}")  
            solanlam.set(f"Số lần làm đề: {dulienbai}")
            scautn.set("Số câu trắc nghiệm: ")
            scautl.set("Số câu tự luận")
            sctg.set("Thời gian làm đề:")
            rate.set("Độ khó:")
            lamde.place(relx = 0, rely = 0.8, relwidth = 0.5)
            kqd.place(relx = 0.55, rely = 0.8, relwidth = 0.4)
        else:
            tende.set("Vui lòng chọn 1 đề")
    bode = {'Đề 1: Chưa biết tên': 1}

    locde = ctk.CTk()
    locde.title('Ôn học sinh giỏi THPT')
    locde.geometry("600x200")
    locde.resizable(False, False)
    
    # FRAME CHỌN ĐỀ
    frmde = ctk.CTkFrame(locde)
    frmde.place(relx=0, rely=0, relwidth=0.6, relheight=1)

    # FRAME ĐỀ
    frmbai = ctk.CTkFrame(locde)
    frmbai.place(relx=0.6, rely=0, relwidth=0.4, relheight=1)

    # LISTBOX 
    de = CTkListbox(frmde, font=("Arial", 11), command=layde)
    de.bind("<Button-1>", layde)
    de.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    # Thêm dữ liệu vào Listbox
    for key, value in bode.items():
        de.insert(ctk.END, key)

    # TÊN ĐỀ
    tende = ctk.StringVar(master=frmbai)
    tende.set("Vui lòng chọn 1 đề")
    lbl_tende = ctk.CTkLabel(frmbai, textvariable=tende, font=("Arial", 11))
    lbl_tende.place(relx=0, rely=0.1, relwidth=1)

    # THÔNG TIN SỐ LẦN LÀM ĐỀ
    solanlam = ctk.StringVar(master=frmbai)
    solanlam.set("")
    lbl_slm = ctk.CTkLabel(frmbai, textvariable=solanlam, font=("Arial", 11))
    lbl_slm.place(relx=0, rely=0.2, relwidth=1)

    # THÔNG TIN ĐỀ
    scautn = ctk.StringVar(master=frmbai)
    scautn.set("")
    lbl_scautn = ctk.CTkLabel(frmbai, textvariable=scautn, font=("Arial", 11), anchor="w")
    lbl_scautn.place(relx=0.05, rely=0.3, relwidth=0.9)

    scautl = ctk.StringVar(master=frmbai)
    scautl.set("")
    lbl_scautl = ctk.CTkLabel(frmbai, textvariable=scautl, font=("Arial", 11), anchor="w")
    lbl_scautl.place(relx=0.05, rely=0.4, relwidth=0.9)

    sctg= ctk.StringVar(master=frmbai)
    sctg.set("")
    lbl_sctg = ctk.CTkLabel(frmbai, textvariable=sctg, font=("Arial", 11), anchor="w")
    lbl_sctg.place(relx=0.05, rely=0.5, relwidth=0.9)

    rate = ctk.StringVar(master=frmbai)
    rate.set("")
    lbl_rate = ctk.CTkLabel(frmbai, textvariable=rate, font=("Arial", 11), anchor="w")
    lbl_rate.place(relx=0.05, rely=0.6, relwidth=0.9)

    # LÀM ĐỀ
    lamde = ctk.CTkButton(master=frmbai, text="Bắt đầu làm bài", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    lamde.bind("<Button-1>", lambda event:tracnghiem(locde,questions_data,ltime,answers))

    # KẾT QUẢ ĐỀ
    kqd = ctk.CTkButton(master=frmbai, text="Xem kết quả", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    kqd.bind("<Button-1>", lambda event: xemkq(questions_data,answers))
    
    capnhat_userdata()

    locde.mainloop()

def root():
    def tents():
        text = entry.get()
        with open("userdata.txt", "r+", encoding="utf-8") as file:
            lines = file.readlines()  
            if lines:
                lines[0] = text + "\n"  
            else:
                lines.append(text + "\n")  

            file.seek(0)  
            file.writelines(lines)  
            file.truncate() 
    def reset():
        with open("userdata.txt", "w") as file:
            default = ["Annonymous"] + ["0 0"] * 3
            file.write("\n".join(default))
        main.destroy()
    main = ctk.CTk()
    main.resizable(False, False)
    main.geometry("800x400+50+50")
    main.title('Canfendania Helper - Phần mềm bổ trợ tin học THPT')

    welcome = ctk.CTkLabel(master=main, text="Chào mừng đến với phần mềm hỗ trợ ôn tin học THPT - Cafendania Helper", font=('Monospace', 12))

    onhsgbutton = ctk.CTkButton(master=main, text="Ôn tin học sinh giỏi", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")

    onhsgbutton.bind("<Button-1>", lambda event: hsg(main))
    welcome.pack(pady=20)
    onhsgbutton.pack(padx=0, pady=50)

    entry = ctk.CTkEntry(main, placeholder_text="Nhập tên thí sinh")
    entry.pack(pady=5)
    button = ctk.CTkButton(main, text="Xác nhận tên thí sinh", command=tents)
    button.pack(pady=0)

    resetbutton = ctk.CTkButton(main, text="Reset", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    resetbutton.bind("<Button-1>", lambda event: reset())
    resetbutton.pack(padx=0, pady=20)


    main.configure(fg_color="#43B3AE")
    main.mainloop()
root()