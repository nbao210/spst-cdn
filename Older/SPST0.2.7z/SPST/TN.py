import customtkinter as ctk

def tracnghiem(de):


    def countdown(time_left, total_time):
        if time_left >= 0:
            hours, remainder = divmod(time_left, 3600)  # Lấy giờ
            minutes, seconds = divmod(remainder, 60)  # Lấy phút và giây
            tilb.configure(text=f"{hours:02}:{minutes:02}:{seconds:02}")
            progress.set((total_time - time_left) / total_time)  

            tn.after(1000, countdown, time_left - 1, total_time)  
        else:
            tilb.configure(text="Time's up!")  
            progress.set(1)  

    tn = ctk.CTk()
    tn.attributes('-fullscreen', True)
    tn.configure(fg_color="#E3E8F0")

    # INFO
    frmif = ctk.CTkFrame(tn, fg_color="#3131AF",border_color = "#3131AF",corner_radius=0)
    frmif.place(relx=0, rely=0, relwidth=0.8, relheight=0.05)

    # TIME
    frmtime = ctk.CTkFrame(tn, fg_color="#FFFFFF",corner_radius=0)
    frmtime.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.05)

    # TIME LABEL
    tilb = ctk.CTkLabel(frmtime, text="180:00", font=("Segoe UI", 15), text_color="black")
    tilb.place(relx=0.1, rely=0.1, relwidth=0.8)

    # PROGRESS BAR
    progress = ctk.CTkProgressBar(frmtime, corner_radius=0)
    progress.place(relx=0, rely=0.9, relwidth=1, relheight=0.1)
    progress.set(0)  

    # TÊN THÍ SINH
    thisinh = ctk.StringVar(master=frmif)
    with open("userdata.txt", "r", encoding="utf-8") as file:
        lines = file.readlines()
    thisinh.set(f"Thí sinh: {lines[0]}")
    lbl_ts = ctk.CTkLabel(frmif, textvariable=thisinh, font=("Arial Bold", 15),text_color="white")
    lbl_ts.place(relx=0.1, rely=0.3, relwidth=0.8)

    # BUTTON
    start_button = ctk.CTkButton(tn, text="Start Countdown", command=lambda: countdown(10800,10800))
    start_button.pack(pady=20)

    tn.mainloop()