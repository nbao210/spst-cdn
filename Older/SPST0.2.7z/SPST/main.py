from TN import tracnghiem
import customtkinter as ctk
from CTkListbox import *

def hsg(main):
    main.destroy()
    
    def layde(event):
        nonlocal tende, solanlam
        selected = de.get()  # Lấy giá trị của phần tử được chọn
        if selected:
            tende.set(selected)  
            with open("userdata.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()
            index = list(bode.keys()).index(selected)  
            dulienbai = int(lines[index+1].strip())  
            solanlam.set(f"Số lần làm đề: {dulienbai}")
            scautn.set("Số câu trắc nghiệm: ")
            scautl.set("Số câu tự luận")
            sctg.set("Thời gian làm đề:")
            rate.set("Độ khó:")
            lamde.place(relx = 0.1, rely = 0.8, relwidth = 0.8)
        else:
            tende.set("Vui lòng chọn 1 đề")
    bode = {'Đề 1: HSG THCS tỉnh Sơn La 2024-2025': 1, 'Đề 2: Đề thử': 2}

    locde = ctk.CTk()
    locde.title('Ôn học sinh giỏi THPT')
    locde.geometry("600x200")
    locde.resizable(False, False)

    # FRAME CHỌN ĐỀ
    frmde = ctk.CTkFrame(locde)
    frmde.place(relx=0, rely=0, relwidth=0.6, relheight=1)

    # FRAME ĐỀ
    frmbai = ctk.CTkFrame(locde)
    frmbai.place(relx=0.6, rely=0, relwidth=0.4, relheight=1)

    # LISTBOX 
    de = CTkListbox(frmde, font=("Arial", 11), command=layde)
    de.bind("<Button-1>", layde)
    de.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    # Thêm dữ liệu vào Listbox
    for key, value in bode.items():
        de.insert(ctk.END, key)

    # TÊN ĐỀ
    tende = ctk.StringVar(master=frmbai)
    tende.set("Vui lòng chọn 1 đề")
    lbl_tende = ctk.CTkLabel(frmbai, textvariable=tende, font=("Arial", 11))
    lbl_tende.place(relx=0, rely=0.1, relwidth=1)

    # THÔNG TIN SỐ LẦN LÀM ĐỀ
    solanlam = ctk.StringVar(master=frmbai)
    solanlam.set("")
    lbl_slm = ctk.CTkLabel(frmbai, textvariable=solanlam, font=("Arial", 11))
    lbl_slm.place(relx=0, rely=0.2, relwidth=1)

    # THÔNG TIN ĐỀ
    scautn = ctk.StringVar(master=frmbai)
    scautn.set("")
    lbl_scautn = ctk.CTkLabel(frmbai, textvariable=scautn, font=("Arial", 11), anchor="w")
    lbl_scautn.place(relx=0.05, rely=0.3, relwidth=0.9)

    scautl = ctk.StringVar(master=frmbai)
    scautl.set("")
    lbl_scautl = ctk.CTkLabel(frmbai, textvariable=scautl, font=("Arial", 11), anchor="w")
    lbl_scautl.place(relx=0.05, rely=0.4, relwidth=0.9)

    sctg= ctk.StringVar(master=frmbai)
    sctg.set("")
    lbl_sctg = ctk.CTkLabel(frmbai, textvariable=sctg, font=("Arial", 11), anchor="w")
    lbl_sctg.place(relx=0.05, rely=0.5, relwidth=0.9)

    rate = ctk.StringVar(master=frmbai)
    rate.set("")
    lbl_rate = ctk.CTkLabel(frmbai, textvariable=rate, font=("Arial", 11), anchor="w")
    lbl_rate.place(relx=0.05, rely=0.6, relwidth=0.9)

    # LÀM ĐỀ
    lamde = ctk.CTkButton(master=frmbai, text="Bắt đầu làm bài", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    lamde.bind("<Button-1>", lambda event:tracnghiem(1))
    

    locde.mainloop()

def root():
    main = ctk.CTk()
    main.resizable(False, False)
    main.geometry("800x400+50+50")
    main.title('Canfendania Helper - Phần mềm bổ trợ tin học THPT')

    welcome = ctk.CTkLabel(master=main, text="Chào mừng đến với phần mềm hỗ trợ ôn tin học THPT - Cafendania Helper", font=('Monospace', 12))

    onhsgbutton = ctk.CTkButton(master=main, text="Ôn tin học sinh giỏi", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")

    onhsgbutton.bind("<Button-1>", lambda event: hsg(main))
    welcome.pack(pady=20)
    onhsgbutton.pack(padx=0, pady=50)

    main.configure(fg_color="#43B3AE")
    main.mainloop()

root()
