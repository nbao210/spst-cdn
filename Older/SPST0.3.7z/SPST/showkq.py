import customtkinter as ctk

def xemkq(questions_data, answers):
    w = ctk.CTkToplevel()
    w.title("Kết quả")
    w.geometry("800x800")
    w.resizable(False, False)
    w.configure(fg_color="#43B3AE")

    frmcau = ctk.CTkScrollableFrame(w, fg_color="transparent")
    frmcau.place(relx=0, rely=0, relwidth=1, relheight=1)

    for idx, (question, options) in enumerate(questions_data):
        frame = ctk.CTkFrame(frmcau, fg_color="white", corner_radius=10)
        frame.pack(pady=10, padx=10, fill="x")

        # Hiển thị câu hỏi
        lbl = ctk.CTkLabel(frame, text=f"Câu {idx+1}: {question}", font=("Arial", 14), text_color="black")
        lbl.pack(anchor="w", padx=10, pady=5)

        # Hiển thị các đáp án
        for ans_idx, ans in enumerate(options):
            ctk.CTkLabel(frame, text=f"{chr(65 + ans_idx)}. {ans}", font=("Arial", 14), text_color="black").pack(anchor="w", padx=20)

        # Hiển thị đáp án đúng
        correct_answer_idx = answers[idx]  
        correct_answer_text = f"Đáp án đúng: {chr(65 + correct_answer_idx)}"
        ctk.CTkLabel(frame, text=correct_answer_text, font=("Arial", 14, "bold"), text_color="green").pack(anchor="w", padx=20, pady=5)

    w.mainloop()
