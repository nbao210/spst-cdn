
import customtkinter as ctk
import tkinter as tk
import sys

def tracnghiem(locde,questions,time,answ):
    #locde.withdraw()
    def countdown(time_left, total_time):
        if time_left >= 0:
            hours, remainder = divmod(time_left, 3600)  # Lấy giờ
            minutes, seconds = divmod(remainder, 60)  # Lấy phút và giây
            tilb.configure(text=f"{hours:02}:{minutes:02}:{seconds:02}")
            progress.set((total_time - time_left) / total_time)  

            tn.after(1000, countdown, time_left - 1, total_time)  
        else:
            tilb.configure(text="Time's up!")  
            progress.set(1)  
            nop_bai()

    tn = ctk.CTk()
    tn.attributes('-fullscreen', True)
    tn.configure(fg_color="#E3E8F0")

    # INFO
    frmif = ctk.CTkFrame(tn, fg_color="#3131AF",border_color = "#3131AF",corner_radius=0)
    frmif.place(relx=0, rely=0, relwidth=0.8, relheight=0.05)

    # TIME
    frmtime = ctk.CTkFrame(tn, fg_color="#FFFFFF",corner_radius=0)
    frmtime.place(relx=0.8, rely=0, relwidth=0.2, relheight=0.05)

    # TIME LABEL
    tilb = ctk.CTkLabel(frmtime, text="180:00", font=("Segoe UI", 15), text_color="black")
    tilb.place(relx=0.1, rely=0.1, relwidth=0.8)

    # PROGRESS BAR
    progress = ctk.CTkProgressBar(frmtime, corner_radius=0, progress_color="#44A5E1")
    progress.place(relx=0, rely=0.9, relwidth=1, relheight=0.2)
    progress.set(0)  

    # TÊN THÍ SINH
    thisinh = ctk.StringVar(master=frmif)
    with open("userdata.txt", "r", encoding="utf-8") as file:
        lines = file.readlines()
    thisinh.set(f"Thí sinh: {lines[0]}")
    lbl_ts = ctk.CTkLabel(frmif, textvariable=thisinh, font=("Arial Bold", 15),text_color="white")
    lbl_ts.place(relx=0.1, rely=0.3, relwidth=0.8)

    # Frame danh sách câu hỏi
    frmlc = ctk.CTkFrame(tn, fg_color='white')
    for i in range(5):  
        frmlc.grid_columnconfigure(i, weight=1)
    frmlc.place(relx=0.8, rely=0.07, relwidth=0.197, relheight=0.92)

    # Khung câu hỏi chính
    frmcau = ctk.CTkScrollableFrame(tn, fg_color="transparent")
    frmcau.place(relx=0, rely=0.05, relwidth=0.8, relheight=0.95)

    # Danh sách đáp án của người dùng
    user_answers = [ctk.IntVar(value=-1) for _ in questions]

    # Tạo danh sách câu hỏi động
    frames = []
    for idx, (question, answers) in enumerate(questions):
        frame = ctk.CTkFrame(frmcau, fg_color="white", corner_radius=10)
        frame.pack(pady=10, padx=10, fill="x")
        
        lbl = ctk.CTkLabel(frame, text=f"Câu {idx+1}: {question}", font=("Arial", 14), text_color="black")
        lbl.pack(anchor="w", padx=10, pady=5)

        for ans_idx, ans in enumerate(answers):
            ctk.CTkRadioButton(frame, text=ans, variable=user_answers[idx], value=ans_idx, font=("Arial", 14), text_color="black").pack(anchor="w", padx=20)

        frames.append(frame)

    # Chuyển đến câu hỏi khi bấm số
    def go_to_question(q):
        frmcau._parent_canvas.yview_moveto(q / len(questions))

    # Tạo bảng danh sách câu hỏi
    frmlc.grid_rowconfigure(0, weight=0)
    lbl_dsch = ctk.CTkLabel(frmlc, text="Danh sách câu hỏi", font=("Arial", 14, "bold"), text_color="black")
    lbl_dsch.grid(row=0, column=0, columnspan=5, pady=10, sticky="ew") 


    for i in range(len(questions)):  
        btn = ctk.CTkButton(frmlc, text=f"{i+1:02d}", width=40, height=40, fg_color="blue",hover_color="darkblue", text_color="white",command=lambda q=i: go_to_question(q))
        row = i // 5
        col = i % 5
        btn.grid(row=row+1, column=col, padx=3, pady=5, sticky="nsew")

    # Nút nộp bài
    def nop_bai():
        result = [var.get() for var in user_answers]
        correct = sum(1 for i in range(len(result)) if result[i] == answ[i])

        with open("userdata.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()

        if len(lines) > 1:
            parts = lines[1].strip().split()
            if parts:
                parts[0] = str(int(parts[0]) + 1)
                parts[1] = str(correct) if len(parts) > 1 else str(correct)
                lines[1] = " ".join(parts) + "\n"

        with open("userdata.txt", "w") as file:
            file.writelines(lines)

        #locde.deiconify()
        tn.destroy()

    submitbtn = ctk.CTkButton(frmlc, text="Nộp bài", command=nop_bai)
    submitbtn.place(relx = 0, rely = 0.9, relwidth = 1, relheight = 0.1)

    countdown(time, time)
    tn.mainloop()
