from TN import tracnghiem
import customtkinter as ctk
from CTkListbox import *
from PIL import Image
import os
from showkq import xemkq
import webbrowser

questions_data = [
    ("Nhập câu hỏi ở đây", 
    [
        "Các câu trả lời"
    ])
]

'0 = A', '1 = B', '2 = C', '3 = D'
answers = [3]
ltime = 60*10 # 10 phút

def hsg(main):
    main.destroy()

    #RELOAD
    def capnhat_userdata():
        if tende.get() in bode:
            with open("userdata.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()
            index = list(bode.keys()).index(tende.get())
            ldl = lines[index+1].strip().split()
            dulienbai = str(f"{ldl[0]} với số điểm {ldl[1]}")
            if solanlam.get() != f"Số lần làm đề: {dulienbai}":
                solanlam.set(f"Số lần làm đề: {dulienbai}")

        locde.after(1000, capnhat_userdata)  
    
    #LAYDE
    def layde(event):
        nonlocal tende, solanlam
        selected = de.get()  # Lấy giá trị của phần tử được chọn
        if selected:
            tende.set(selected)  
            with open("userdata.txt", "r", encoding="utf-8") as file:
                lines = file.readlines()
            index = list(bode.keys()).index(selected) 
            ldl = lines[index+1].strip().split() 
            dulienbai = str(f"{ldl[0]} với số điểm {ldl[1]}")  
            solanlam.set(f"Số lần làm đề: {dulienbai}")
            scautn.set("Số câu trắc nghiệm: ")
            scautl.set("Số câu tự luận")
            sctg.set("Thời gian làm đề:")
            rate.set("Độ khó:")
            lamde.place(relx = 0, rely = 0.8, relwidth = 0.5)
            kqd.place(relx = 0.55, rely = 0.8, relwidth = 0.4)
            return index
        else:
            tende.set("Vui lòng chọn 1 đề")
    bode = {'Đề 1: Chưa biết tên': 1, 'Đề 2: Chưa biết tên': 2, 'Đề 3: Chưa biết tên': 3, 'Đề 4: Chưa biết tên': 4, 'Đề 5: Chưa biết tên': 5}

    #INIT 
    locde = ctk.CTk()
    locde.title("Ôn học sinh giỏi THPT")
    locde.geometry("800x450")
    locde.minsize(600,400)

    # Cấu hình lưới 1x2
    locde.grid_rowconfigure(0, weight=1)
    locde.grid_columnconfigure(1, weight=1)

    # Đường dẫn hình ảnh
    image_path = os.path.join(os.path.dirname(__file__), "test_images")

    # Tải hình ảnh
    logo_img = ctk.CTkImage(Image.open(os.path.join(image_path, "CustomTkinter_logo_single.png")), size=(26, 26))
    home_img = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "home_dark.png")),
                            dark_image=Image.open(os.path.join(image_path, "home_light.png")), size=(24, 24))
    add_img = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "chat_dark.png")),
                           dark_image=Image.open(os.path.join(image_path, "chat_light.png")), size=(24, 24))
    tg_img = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "author_light.png")),
                            dark_image = Image.open(os.path.join(image_path, "author_dark.png")), size=(24, 24))
    setting_img = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "setting_light.png")),
                            dark_image = Image.open(os.path.join(image_path, "setting_dark.png")), size=(24, 24))

    # Tạo thanh điều hướng
    nav_frame = ctk.CTkFrame(locde, corner_radius=0)
    nav_frame.grid(row=0, column=0, sticky="nsew")
    nav_frame.grid_rowconfigure(5, weight=1)

    nav_label = ctk.CTkLabel(nav_frame, text="  Phần mềm ôn thi tin", image=logo_img, compound="left")
    nav_label.grid(row=0, column=0, padx=20, pady=20)

    button_style = {"anchor": "w", "height": 40, "border_spacing": 12, "font": ("Arial", 14), "hover_color": ("gray70", "gray30"),"text_color": ("black", "white")}
    
    btn_home = ctk.CTkButton(nav_frame, text="Trang chủ", image=home_img, fg_color="transparent", corner_radius=0, **button_style)
    btn_home.grid(row=1, column=0, sticky="nsew")

    btn_add = ctk.CTkButton(nav_frame, text="Tìm thêm đề", image=add_img, fg_color="transparent", corner_radius=0, **button_style)
    btn_add.grid(row=2, column=0, sticky="nsew")

    btn_tg = ctk.CTkButton(nav_frame, text="Thông tin tác giả", image=tg_img, fg_color = "transparent", corner_radius = 0, **button_style)
    btn_tg.grid(row=3, column=0, sticky = "nsew")

    btn_st = ctk.CTkButton(nav_frame, text="Cài đặt", image=setting_img, fg_color = "transparent", corner_radius = 0, **button_style)
    btn_st.grid(row=4, column=0, sticky = "nsew")

    # Tạo các frame
    home_frame = ctk.CTkFrame(locde, corner_radius=0, fg_color="transparent")
    add_frame = ctk.CTkFrame(locde, corner_radius=0, fg_color="transparent")
    tg_frame = ctk.CTkFrame(locde, corner_radius=0, fg_color="transparent")
    st_frame = ctk.CTkFrame(locde, corner_radius=0, fg_color="transparent")

    #APP MODE
    default_mode = "System" 
    ctk.set_appearance_mode(default_mode)

    appearance_menu = ctk.CTkOptionMenu(nav_frame, values=["Light", "Dark", "System"], command=lambda mode: ctk.set_appearance_mode(mode))
    appearance_menu.set(default_mode) 
    appearance_menu.grid(row=6, column=0, padx=20, pady=5, sticky="s")

    versionapp = ctk.CTkLabel(nav_frame, text="pre-release 0.5", font=("Arial", 10))
    versionapp.grid(row=7, column=0, padx=20, sticky="s")

    # Cấu hình cột lưới của các frame
    home_frame.grid_columnconfigure(0, weight=1)
    add_frame.grid_columnconfigure((0,1), weight=1)
    tg_frame.grid_columnconfigure(0, weight=1)
    st_frame.grid_columnconfigure(0, weight=1)

    # TRANG ADD
    home_frame.grid(row=0, column=1, sticky="nsew")
    homelbl = ctk.CTkLabel(add_frame, text="Service currently unavalible!", font=("Arial", 16))

    mkp = ctk.CTkLabel(
        add_frame, 
        text="Giải pháp tạm thời: truy cập\nhttps://nbao210.github.io/spst-cdn/", 
        text_color="blue", 
        cursor="hand2"
    )
    mkp.bind("<Button-1>", lambda event: webbrowser.open("https://nbao210.github.io/spst-cdn/")) 

    homelbl.grid(row=0, column=0, columnspan=2, padx=20, pady=20, sticky="nsew")
    mkp.grid(row=1, column=0, columnspan=2, padx=20, pady=20, sticky="nsew")


    # LỆNH SWICH FRAME
    def switch_frame(name):
        btn_home.configure(fg_color=("gray75", "gray25") if name == "home" else "transparent")
        btn_add.configure(fg_color=("gray75", "gray25") if name == "add" else "transparent")
        btn_tg.configure(fg_color=("gray75", "gray25") if name == "tg" else "transparent")
        btn_st.configure(fg_color=("gray75", "gray25") if name == "st" else "transparent")

        home_frame.grid_forget()
        add_frame.grid_forget()
        tg_frame.grid_forget()
        st_frame.grid_forget()

        if name == "home":
            home_frame.grid(row=0, column=1, sticky="nsew")
        elif name == "add":
            add_frame.grid(row=0, column=1, sticky="nsew")
        elif name == "tg":
            tg_frame.grid(row=0, column = 1, sticky = "nsew")
        elif name == "st":
            st_frame.grid(row=0, column = 1, sticky = "nsew")

    btn_home.configure(command=lambda: switch_frame("home"))
    btn_add.configure(command=lambda: switch_frame("add"))
    btn_tg.configure(command=lambda: switch_frame("tg"))
    btn_st.configure(command=lambda: switch_frame("st"))    

    # Tính năng thông thường
    frmde = ctk.CTkFrame(home_frame, fg_color="transparent")
    frmde.place(relx=0, rely=0, relwidth=0.5, relheight=1)

    # FRAME ĐỀ
    frmbai = ctk.CTkFrame(home_frame, fg_color="transparent")
    frmbai.place(relx=0.5, rely=0, relwidth=0.5, relheight=1)

    # LISTBOX 
    de = CTkListbox(frmde, font=("Arial", 11), command=layde)
    de.bind("<Button-1>", layde)
    de.place(relx=0.03, rely=0.03, relwidth=0.95, relheight=0.95)
    
    # Thêm dữ liệu vào Listbox
    for key, value in bode.items():
        de.insert(ctk.END, key)

    # TT ĐỀ
    frmbai.grid_columnconfigure(0, weight=1)
    frmbai.grid_rowconfigure((0, 1, 2, 3, 4, 5, 6,7,8,9,10), weight=0)

    tende = ctk.StringVar(master=frmbai)
    tende.set("Vui lòng chọn 1 đề")

    solanlam = ctk.StringVar(master=frmbai)
    solanlam.set("")

    scautn = ctk.StringVar(master=frmbai)
    scautn.set("")

    scautl = ctk.StringVar(master=frmbai)
    scautl.set("")

    sctg= ctk.StringVar(master=frmbai)
    sctg.set("")

    rate = ctk.StringVar(master=frmbai)
    rate.set("")

    lbl_tende = ctk.CTkLabel(frmbai, textvariable=tende, font=("Arial", 15))
    lbl_tende.grid(row=0, column=0, padx=20, pady=50, sticky="w e")

    lbl_slm = ctk.CTkLabel(frmbai, textvariable=solanlam, font=("Arial", 15))
    lbl_slm.grid(row=1, column=0, padx=20, pady=0, sticky="w")

    lbl_scautn = ctk.CTkLabel(frmbai, textvariable=scautn, font=("Arial", 15), anchor="w")
    lbl_scautn.grid(row=2, column=0, padx=20, pady=0, sticky="w")

    lbl_scautl = ctk.CTkLabel(frmbai, textvariable=scautl, font=("Arial", 15), anchor="w")
    lbl_scautl.grid(row=3, column=0, padx=20, pady=0, sticky="w")

    lbl_sctg = ctk.CTkLabel(frmbai, textvariable=sctg, font=("Arial", 15), anchor="w")
    lbl_sctg.grid(row=4, column=0, padx=20, pady=0, sticky="w")

    lbl_rate = ctk.CTkLabel(frmbai, textvariable=rate, font=("Arial", 15), anchor="w")
    lbl_rate.grid(row=5, column=0, padx=20, pady=0, sticky="w")

    def stn():
        sel = de.get()
        idx = list(bode.keys()).index(sel)
        tracnghiem(locde,questions_data,ltime,answers,idx)

    # LÀM ĐỀ
    lamde = ctk.CTkButton(master=frmbai, text="Bắt đầu làm bài", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    lamde.bind("<Button-1>", lambda event:stn())

    # KẾT QUẢ ĐỀ
    kqd = ctk.CTkButton(master=frmbai, text="Xem kết quả", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    kqd.bind("<Button-1>", lambda event: xemkq(questions_data,answers))
    
    capnhat_userdata()

    # ========================= SETTING ==========================
    tab = ctk.CTkTabview(st_frame)
    tab.place(relx=0.03, rely=0.02, relwidth=0.95, relheight=0.96)

    gn = tab.add("General")
    sv = tab.add("Server")

    sv.grid_rowconfigure(2)
    sv.grid_columnconfigure(1, weight=1)
    sv.grid_columnconfigure((2,3), weight=0)

    gn.grid_rowconfigure(2)
    gn.grid_columnconfigure(1)

    # GENERAL
    def savest(x,ln):
        state = x.get()  
        with open("setting.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()
            parts = lines[ln].strip().split()
            if parts:
                if state == 1:
                    parts[1] = "1"
                else:
                    parts[1] = "0"
                lines[ln] = " ".join(parts) + "\n"
        with open("setting.txt", "w", encoding= "utf-8") as file:
            file.writelines(lines)

    fsw = ctk.CTkSwitch(gn, text="Toàn màn hình")
    fsw.configure(command = lambda: savest(fsw,1))
    fsw.grid(row = 0, column = 0,padx= 20, sticky="nsew")

    with open("setting.txt", "r", encoding="utf-8") as file:
        lines = file.readlines()
        if len(lines) > 1:
            parts = lines[1].strip().split()
            if parts[1] == "1": fsw.select()
            else: fsw.deselect()

    # SERVER
    def svcof():
        cf.grid(row=2, column=1, sticky="n")

    svip = ctk.CTkEntry(sv, placeholder_text="Enter server IP (default: https://nbao210.github.io/spst-cdn/)")
    svip.grid(row=1, column=1, padx=(20,0), sticky="nsew")

    svcf = ctk.CTkButton(sv, text="Xác nhận", command=svcof)  # Remove parentheses
    svcf.grid(row=1, column=3, padx = (5,20), sticky="nsew")

    cf = ctk.CTkLabel(sv, text="Under construction")

    #AUTHOR
    tg_frame.grid_rowconfigure(3, weight=0)  
    tg_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5,6), weight=1)

    # Hiển thị ảnh đại diện
    avt = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "auth.png")), size=(200, 200))
    avp = ctk.CTkLabel(tg_frame, image=avt, text="")  # Không có text để tránh khoảng trắng
    avp.grid(row=1, column=0, columnspan=5, pady=(30, 2), sticky="n")

    # Hiển thị tên ngay dưới ảnh
    name = ctk.CTkLabel(tg_frame, text="Nguyễn Gia Bảo", font=("Arial", 18, "bold"))
    name.grid(row=2, column=0, columnspan=5, pady=0, sticky="n")

    dvl = ctk.CTkLabel(tg_frame, text = "<a> Python, C++, C#, web developer </a>", font=("SegoeUI",12), text_color="gray")
    dvl.grid(row=3, column = 0, columnspan = 5, pady=0, sticky = "n")

    dt = ctk.CTkLabel(tg_frame, text ="From THCS Nguyễn Trãi", font=("Arial", 12), text_color="gray")
    dt.grid(row=4, column=0, columnspan=5, pady=0, sticky ="n")

    # Tạo frame chứa các nút và căn giữa
    buttons_frame = ctk.CTkFrame(tg_frame, fg_color="transparent")
    buttons_frame.grid(row=5, column=0, columnspan=5, pady=(5, 0), sticky="n")

    # Tạo hình ảnh cho các nút
    face = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "facebook.png")), size=(35, 35))
    you = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "youtube.png")), size=(40, 30))
    dis = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "discord.png")), size=(45, 25))
    wb = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "web.png")), size=(35, 35))
    git = ctk.CTkImage(light_image=Image.open(os.path.join(image_path, "github.png")), size=(35, 35))

    # Tạo các nút hình ảnh
    fb = ctk.CTkButton(buttons_frame, image=face, width=70, height=70, text="", fg_color="transparent", command=lambda: webbrowser.open("https://www.facebook.com/daisuh2cl/"))
    yt = ctk.CTkButton(buttons_frame, image=you, width=70, height=70, text="", fg_color="transparent", command=lambda: webbrowser.open("https://www.youtube.com/@wonggrow"))
    dc = ctk.CTkButton(buttons_frame, image=dis, width=70, height=70, text="", fg_color="transparent", command=lambda: webbrowser.open("https://guns.lol/windows10x"))
    web = ctk.CTkButton(buttons_frame, image=wb, width=70, height=70, text="", fg_color="transparent", command=lambda: webbrowser.open("https://nbaowebpro.web.app"))
    gh = ctk.CTkButton(buttons_frame, image=git, width=70, height=70, text="", fg_color="transparent", command=lambda: webbrowser.open("https://github.com/nbao210/spst-cdn"))

    # Căn giữa các nút trong frame
    buttons_frame.grid_columnconfigure((0, 1, 2, 3, 4), weight=1)
    fb.grid(row=0, column=0, padx=5, pady=5)
    yt.grid(row=0, column=1, padx=5, pady=5)
    dc.grid(row=0, column=2, padx=5, pady=5)
    web.grid(row=0, column=3, padx=5, pady=5)
    gh.grid(row=0, column=4, padx=5, pady=5)

    locde.mainloop()

def root():
    def tents():
        text = entry.get()
        with open("userdata.txt", "r+", encoding="utf-8") as file:
            lines = file.readlines()  
            if lines:
                lines[0] = text + "\n"  
            else:
                lines.append(text + "\n")  

            file.seek(0)  
            file.writelines(lines)  
            file.truncate() 
    def reset():
        with open("userdata.txt", "w") as file:
            default = ["Annonymous"] + ["0 0"] * 5
            file.write("\n".join(default))
        main.destroy()
    main = ctk.CTk()
    main.resizable(False, False)
    main.geometry("800x400+50+50")
    main.title('Canfendania Helper - Phần mềm bổ trợ tin học THPT')

    welcome = ctk.CTkLabel(master=main, text="Chào mừng đến với phần mềm hỗ trợ ôn tin học THPT - Cafendania Helper", font=('Monospace', 12))

    onhsgbutton = ctk.CTkButton(master=main, text="Ôn tin học sinh giỏi", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")

    onhsgbutton.bind("<Button-1>", lambda event: hsg(main))
    welcome.pack(pady=20)
    onhsgbutton.pack(padx=0, pady=50)

    entry = ctk.CTkEntry(main, placeholder_text="Nhập tên thí sinh")
    entry.pack(pady=5)
    button = ctk.CTkButton(main, text="Xác nhận tên thí sinh", command=tents)
    button.pack(pady=0)

    resetbutton = ctk.CTkButton(main, text="Reset", font=("Arial", 12), fg_color="#3b8ed0",hover_color = "#36719F")
    resetbutton.bind("<Button-1>", lambda event: reset())
    resetbutton.pack(padx=0, pady=20)


    main.configure(fg_color="#43B3AE")
    main.mainloop()
root()