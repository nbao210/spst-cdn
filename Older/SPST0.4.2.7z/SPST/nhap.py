import customtkinter as ctk
import webview
import threading

class WebViewFrame(ctk.CTkFrame):
    def __init__(self, master, url, **kwargs):
        super().__init__(master, **kwargs)
        self.url = url
        self.init_webview()

    def init_webview(self):
        self.browser_frame = ctk.CTkFrame(self)
        self.browser_frame.pack(fill="both", expand=True)
        self.after(100, self.start_webview)  # Chạy WebView sau khi khởi tạo Tkinter

    def start_webview(self):
        # Lấy ID của Frame để nhúng WebView vào
        window_id = self.browser_frame.winfo_id()
        
        # Chạy WebView trong luồng riêng
        threading.Thread(target=lambda: webview.create_window("WebView", self.url, frameless=True, window=window_id), daemon=True).start()

# Tạo ứng dụng CustomTkinter
root = ctk.CTk()
root.geometry("800x600")

web_frame = WebViewFrame(root, "https://www.google.com")
web_frame.pack(fill="both", expand=True)

root.mainloop()
